""" auth/urls.py: URL endpoints for Authentication. """

from django.conf.urls import url, include

# def password_reset_confirm_redirect(_, uidb64, token):
#     return redirect('%s/password/reset/confirm/%s/%s' % (settings.FRONTEND_URL, uidb64, token))

# def account_confirm_email_redirect(request, key):
#     return redirect('%s/account/verify/%s' % (settings.FRONTEND_URL, key))


urlpatterns = [
    url(r'^register/', include('rest_auth.registration.urls')),
    url(r'^account/', include('allauth.urls')),
    url(r'^', include('rest_auth.urls')),

    # verify email registration
    # url(r"^account/confirm-email/(?P<key>[\s\d\w().+-_',:&]+)/$",
    #     account_confirm_email_redirect,
    #     name="account_confirm_email"),

    # confirm password reset
    # url(r'^password/reset/confirm/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
    #     password_reset_confirm_redirect,
    #     name='password_reset_confirm'),
]
