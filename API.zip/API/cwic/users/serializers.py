""" users/serializers.py: Serializers for User Profiles. """

from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Avatar, Profile


class AvatarSerializer(serializers.ModelSerializer):
    class Meta:
        model = Avatar
        fields = ('image',)

    def create(self, validated_data):
        avatar = super(AvatarSerializer, self).create(validated_data)
        user = self.context['request'].user
        profile = user.profile
        profile.avatar = avatar
        profile.save()
        return avatar


class PublicUserSerializer(serializers.ModelSerializer):
    avatar = serializers.ImageField(source='profile.avatar.image',
                                    read_only=True)
    user_type = serializers.CharField(source='profile.user_type')

    class Meta:
        model = User
        fields = ('id', 'username', 'first_name', 'last_name',
                  'avatar', 'user_type',)


class ProfileUpdateSerializer(serializers.ModelSerializer):
    avatar = serializers.ImageField(source='avatar.image', read_only=True)

    class Meta:
        model = Profile
        fields = ('avatar', 'birthdate', 'gender', 'gender_name', 'hometown',
                  'how_discovered', 'user_type', 'user_type_name',
                  'years_attended',)


class UserUpdateSerializer(serializers.ModelSerializer):
    username = serializers.CharField(read_only=True)
    profile = ProfileUpdateSerializer()

    class Meta:
        model = User
        fields = ('id', 'username', 'first_name', 'last_name', 'profile',)

    def update(self, user, validated_data):
        print('validated_data', validated_data)
        profile = user.profile
        print('profile', profile)
        profile_data = validated_data.pop('profile', {})
        print('profile_data', profile_data)
        super(UserUpdateSerializer, self).update(profile, profile_data)
        return super(UserUpdateSerializer, self).update(user, validated_data)

        # class PrivateUserSerializer(serializers.ModelSerializer):
        #     username = serializers.CharField(read_only=True)
        #     avatar = serializers.ImageField(source='profile.avatar.image',
        #                                     read_only=True)
        #     birthdate = serializers.DateField(source='profile.birthdate')
        #     gender = serializers.CharField(source='profile.gender', allow_blank=True)
        #     gender_name = serializers.CharField(source='profile.gender_name')
        #     hometown = serializers.CharField(source='profile.hometown',
        #                                      allow_blank=True)
        #     how_discovered = serializers.CharField(source='profile.how_discovered',
        #                                            allow_blank=True)
        #     user_type = serializers.CharField(source='profile.user_type')
        #     user_type_name = serializers.CharField(source='profile.user_type_name')
        #     years_attended = serializers.IntegerField(source='profile.years_attended')
        #
        #     class Meta:
        #         model = User
        #         fields = (
        #             'id', 'username', 'first_name', 'last_name', 'avatar',
        #             'birthdate', 'gender', 'gender_name', 'hometown',
        #             'how_discovered', 'user_type', 'user_type_name', 'years_attended',
        #         )

        # def update(self, user, validated_data):
        #     print('validated_data', validated_data)
        #     profile = user.profile
        #     print('profile', profile)
        #     profile_data = validated_data.pop('profile', None)
        #     print('profile_data', profile_data)
        #     super(PrivateUserSerializer, self).update(profile, profile_data)
        #     return super(PrivateUserSerializer, self).update(user, validated_data)

# class ProfileSerializer(serializers.ModelSerializer):
#     avatar = serializers.ImageField(source='avatar.image', read_only=True)
#
#     class Meta:
#         model = Profile
#         fields = ('id', 'avatar', 'about', 'birthdate', 'gender', 'hometown',
#                   'how_discovered', 'user_type', 'years_attended',)
#
#
# class UserSerializer(serializers.ModelSerializer):
#     profile = ProfileSerializer()
#
#     class Meta:
#         model = User
#         fields = ('username', 'first_name', 'last_name', 'profile',)
#
#     def update(self, user, vd):
#         # User data
#         user.first_name = vd['first_name']
#         user.last_name = vd['last_name']
#
#         # User Profile data
#         user.profile.about = vd['profile']['about']
#         user.profile.birthdate = vd['profile']['birthdate']
#         user.profile.gender = vd['profile']['gender']
#         user.profile.hometown = vd['profile']['hometown']
#         user.profile.how_discovered = vd['profile']['how_discovered']
#         user.profile.user_type = vd['profile']['user_type']
#         user.profile.hometown = vd['profile']['hometown']
#         user.profile.years_attended = vd['profile']['years_attended']
#         user.save()
#
#         return user
