""" users/models.py: Models for User Profiles. """

from django.contrib.auth.models import User
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token
from phonenumber_field.modelfields import PhoneNumberField
from cwic import helpers

USER_TYPES = [
    ('A', 'Artist'),
    ('C', 'Committee Member'),
    ('J', 'Judge'),
    ('L', 'Team Leader'),
    ('M', 'Team Member'),
    ('S', 'Sponsor'),
    ('V', 'Visitor'),
]

GENDERS = [
    ('M', 'Male'),
    ('F', 'Female'),
    ('U', 'Unspecified'),
]


class Avatar(models.Model):
    image = models.ImageField(upload_to=helpers.avatar_location,
                              default='avatar/avatar.png')

    def __str__(self):
        return self.image.name


class Profile(models.Model):
    user = models.OneToOneField(User)
    avatar = models.ForeignKey(Avatar, blank=True, null=True)

    about = models.TextField(default='', blank=True)
    birthdate = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=1, choices=GENDERS, default='U')
    hometown = models.CharField(max_length=255, blank=True, default='')
    how_discovered = models.TextField(blank=True, null=True)
    user_type = models.CharField(max_length=1, choices=USER_TYPES, default='V')
    years_attended = models.IntegerField(blank=True, null=True)
    phone_number = PhoneNumberField(blank=True)

    @property
    def user_type_name(self):
        return dict(USER_TYPES)[self.user_type]

    @property
    def gender_name(self):
        return dict(GENDERS)[self.gender]

    def __str__(self):
        return self.user.username


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
        Token.objects.create(user=instance)
    instance.profile.save()
