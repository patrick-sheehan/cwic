""" users/views.py: Views for User Profiles. """

from django.contrib.auth.models import User
from rest_framework import exceptions, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from cwic import helpers
from .serializers import (
    AvatarSerializer,
    PublicUserSerializer,
    UserUpdateSerializer,
)


def get_users_of_type(user_type):
    qs = User.objects.all()
    return [u for u in qs if u.profile.user_type.lower() == user_type.lower()]


class UserViewSet(helpers.ModelWithRequestViewSet):
    """ View Users and update Profile. """

    def get_queryset(self):
        user_type = self.request.query_params.get('user_type', None)
        if user_type is not None:
            return get_users_of_type(user_type)
        return User.objects.all()

    def get_serializer_class(self):
        if self.get_object() == self.request.user:
            return UserUpdateSerializer
        return PublicUserSerializer

    def get_object(self):
        if 'pk' not in self.kwargs:
            return self.request.user
        return super(UserViewSet, self).get_object()

    def check_permissions(self, request):
        super(UserViewSet, self).check_permissions(request)
        if self.action == 'partial_update':
            if not self.get_object() == request.user:
                raise exceptions.PermissionDenied


user_detail = UserViewSet.as_view({
    'get': 'retrieve', 'patch': 'partial_update'})
user_list = UserViewSet.as_view({'get': 'list'})


class AvatarViewSet(helpers.ModelWithRequestViewSet):
    """ Update User Profile Avatar. """

    serializer_class = AvatarSerializer

    def get_object(self):
        return self.request.user.profile.avatar

    def destroy(self, request, *args, **kwargs):
        profile = request.user.profile
        profile.avatar = None
        profile.save()
        return Response(status=status.HTTP_204_NO_CONTENT)


avatar_detail = AvatarViewSet.as_view({
    'get': 'retrieve', 'post': 'create', 'delete': 'destroy'})


@api_view(['GET', ])
def my_account_id(request):
    """ Get current User's id """
    if not request.user.is_authenticated:
        raise exceptions.PermissionDenied()
    return Response({'id': request.user.id})
