from django.contrib import admin
from .models import Avatar, Profile


class ProfileModelAdmin(admin.ModelAdmin):
    fields = ('user', 'user_type', 'avatar',)
    list_display = list_display_links = fields

    class Meta:
        model = Profile

admin.site.register(Avatar)
admin.site.register(Profile, ProfileModelAdmin)
