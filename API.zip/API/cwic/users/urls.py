""" users/urls.py: URL endpoints for User Profiles. """

from django.conf.urls import url
from .views import (
    avatar_detail,
    my_account_id,
    user_detail,
    user_list,
)

urlpatterns = [
    url(r'^$', user_list, name='list'),
    url(r'^avatar/$', avatar_detail, name='avatar'),
    url(r'^mine/$', my_account_id, name='mine'),
    url(r'^(?P<pk>\d+)/$', user_detail, name='detail'),
]
