""" cwic/wsgi.py: Project-level WSGI config. """

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "cwic.settings")

application = get_wsgi_application()
