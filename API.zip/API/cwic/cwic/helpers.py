""" cwic/helpers.py: General utilities used throughout project. """

from django.db import models
from rest_framework import viewsets

# fields.py
class CreatedTimeField(models.DateTimeField):
    def __init__(self, *args, **kwargs):
        kwargs['auto_now'] = False
        kwargs['auto_now_add'] = True
        super(CreatedTimeField, self).__init__(*args, **kwargs)


class UpdatedTimeField(models.DateTimeField):
    def __init__(self, *args, **kwargs):
        kwargs['auto_now'] = True
        kwargs['auto_now_add'] = False
        super(UpdatedTimeField, self).__init__(*args, **kwargs)


# mixins.py
class RequestMixin(object):
    def get_serializer_context(self):
        return {'request': self.request, 'user': self.request.user}


class ModelWithRequestViewSet(RequestMixin, viewsets.ModelViewSet):
    pass

# uploads.py
def event_location(instance, filename):
    return 'events/%s' % filename


def avatar_location(instance, filename):
    return 'avatar/%s' % filename


def logo_location(instance, filename):
    return 'logo/%s' % filename


def auction_item_location(instance, filename):
    return 'auctionitem/%s' % filename
