from django.apps import AppConfig


class SponsorsConfig(AppConfig):
    name = 'sponsors'
