""" sponsors/models.py: Models for Sponsors. """

from django.db import models
from cwic import helpers


class Sponsor(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(default='', blank=True)
    logo = models.ImageField(upload_to=helpers.logo_location)

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name
