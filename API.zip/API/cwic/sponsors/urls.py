""" sponsors/urls.py: URLs for Sponsors. """

from django.conf.urls import url

from .views import (
    sponsor_list,
    sponsor_detail,
)

urlpatterns = [
    url(r'^$', sponsor_list, name='list'),
    url(r'^(?P<pk>\d+)/$', sponsor_detail, name='detail'),
]
