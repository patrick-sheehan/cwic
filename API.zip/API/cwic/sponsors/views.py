""" sponsors/views.py: Views for Sponsors. """

from rest_framework import viewsets
from .serializers import Sponsor, SponsorSerializer


class SponsorViewSet(viewsets.ModelViewSet):
    queryset = Sponsor.objects.all()
    serializer_class = SponsorSerializer


sponsor_list = SponsorViewSet.as_view({'get': 'list',
                                       'post': 'create'})
sponsor_detail = SponsorViewSet.as_view({'get': 'retrieve',
                                         'patch': 'partial_update',
                                         'delete': 'destroy'})
