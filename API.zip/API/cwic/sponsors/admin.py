from django.contrib import admin
from sponsors.models import Sponsor

admin.site.register(Sponsor)
