""" events/serializers.py: Serializers for Events. """

from django.utils.timesince import timesince
from rest_framework import serializers
from users.serializers import PublicUserSerializer
from .models import (
    AuctionItem,
    Auction,
    Comment,
    Concert,
    Cookoff,
    CookoffTeam,
    Event,
    Position,
    Starred,
)


class PositionSerializer(serializers.ModelSerializer):
    lat = serializers.FloatField(required=False)
    lon = serializers.FloatField(required=False)

    class Meta:
        model = Position
        fields = ('lat', 'lon',)


class CommentSerializer(serializers.ModelSerializer):
    created = serializers.SerializerMethodField()
    creator = serializers.CharField(source='creator.username', read_only=True)

    class Meta:
        model = Comment
        fields = ('text', 'created', 'creator',)

    def get_created(self, comment):
        return '%s ago' % timesince(comment.created)


class EventSerializer(serializers.HyperlinkedModelSerializer):
    image = serializers.ImageField(
        allow_null=True, allow_empty_file=True, required=False)
    position = PositionSerializer(required=False, allow_null=True)
    url = serializers.HyperlinkedIdentityField(view_name='events:detail')
    comments = CommentSerializer(many=True)
    is_starred = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = ('id', 'url', 'title', 'description', 'date', 'type',
                  'type_verbose', 'image', 'position', 'is_starred',
                  'comments',)

    def get_is_starred(self, event):
        user = self.context['request'].user
        return Starred.objects.filter(event=event, user=user).exists()


class AuctionSerializer(serializers.HyperlinkedModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name='events:auction-detail')

    class Meta:
        model = Auction
        fields = ('url', 'title', 'description', 'date', 'image',)


class AuctionItemSerializer(serializers.ModelSerializer):
    image = serializers.ImageField(
        allow_null=True, allow_empty_file=True, required=False)

    class Meta:
        model = AuctionItem
        fields = ('id', 'name', 'image',)


class AuctionDetailSerializer(serializers.ModelSerializer):
    items = AuctionItemSerializer(many=True)

    class Meta:
        model = Auction
        fields = ('id', 'title', 'items')


class ConcertSerializer(serializers.ModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name='events:concert-detail')
    artist = PublicUserSerializer(read_only=True)

    class Meta:
        model = Concert
        fields = ('url', 'title', 'description', 'date', 'image', 'artist',)


class CookoffSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cookoff
        fields = '__all__'
