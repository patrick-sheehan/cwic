""" events/urls.py: URLs for Events. """

from django.conf.urls import url

from .views import (
    auction_detail,
    auction_item_list,
    auction_list,
    concert_detail,
    concert_list,
    cookoff_detail,
    cookoff_list,
    comment_list,
    event_detail,
    event_list,
    event_star,
)

urlpatterns = [

    # All Events
    url(r'^$', event_list, name='list'),
    url(r'^(?P<pk>\d+)/$', event_detail, name='detail'),
    url(r'^(?P<pk>\d+)/star/$', event_star, name='star'),
    url(r'^(?P<pk>\d+)/comments/$', comment_list, name='comments'),

    # Auctions
    url(r'^auctions/$', auction_list, name='auction-list'),
    url(r'^auctions/(?P<pk>\d+)/$', auction_detail, name='auction-detail'),
    url(r'^auctions/(?P<pk>\d+)/items/$', auction_item_list,
        name='auction-item-list'),

    # Concerts
    url(r'^concerts/$', concert_list, name='concert-list'),
    url(r'^concerts/(?P<pk>\d+)/$', concert_detail, name='concert-detail'),

    # Cookoffs
    url(r'^cookoffs/$', cookoff_list, name='cookoff-list'),
    url(r'^cookoffs/(?P<pk>\d+)/$', cookoff_detail, name='cookoff-detail'),
]
