""" events/views.py: Views for Events. """

from rest_framework import filters
from rest_framework.decorators import api_view
from rest_framework.response import Response
from cwic.helpers import ModelWithRequestViewSet
from .models import (
    Auction,
    AuctionItem,
    Concert,
    Comment,
    Cookoff,
    CookoffTeam,
    Event,
    EVENT_TYPES,
    Starred,
)
from .serializers import (
    AuctionSerializer,
    AuctionDetailSerializer,
    AuctionItemSerializer,
    CommentSerializer,
    ConcertSerializer,
    CookoffSerializer,
    EventSerializer,
)


class EventViewSet(ModelWithRequestViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    filter_backends = (filters.SearchFilter,)
    search_fields = ('title', 'description',)

    def get_queryset(self):
        user = self.request.user
        qs = Event.objects.all()

        # Filtered by Category
        category = self.request.query_params.get('category', None)
        if category is not None:
            return Event.objects.for_category_name(category)

        # Filtered by Status of current user
        status = self.request.query_params.get('status', None)
        if status is not None:
            status = status.lower()
            if status == 'starred':
                return Event.objects.starred(user)
            elif status == 'trending':
                return sorted(qs[:10], key=lambda t: -t.popularity)

        return qs


event_list = EventViewSet.as_view({'get': 'list', 'post': 'create'})
event_detail = EventViewSet.as_view({
    'get': 'retrieve', 'patch': 'partial_update', 'delete': 'destroy'})


@api_view(['PUT', 'GET', 'DELETE'])
def event_star(request, pk):
    """ Star or unstar an Event. Repeats are ignored. """

    event = Event.objects.get(pk=pk)
    user = request.user

    qs = Starred.objects.filter(event=event, user=user)

    if request.method == 'PUT':
        if not qs.exists():
            Starred.objects.create(event=event, user=user)

    if request.method == 'DELETE':
        qs.delete()

    return Response({'result': qs.exists()})


class CommentViewSet(ModelWithRequestViewSet):
    """ Comments on an Event. """

    serializer_class = CommentSerializer

    def get_queryset(self):
        return Comment.objects.filter(event=self.kwargs['pk'])

    def perform_create(self, serializer):
        serializer.save(event=Event.objects.get(pk=self.kwargs['pk']),
                        creator=self.request.user)


comment_list = CommentViewSet.as_view({'get': 'list', 'post': 'create'})


class AuctionViewSet(ModelWithRequestViewSet):
    queryset = Auction.objects.all()
    serializer_class = AuctionSerializer

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return AuctionDetailSerializer
        return AuctionSerializer

    def perform_create(self, serializer):
        serializer.save(type='U')


auction_list = AuctionViewSet.as_view({'get': 'list', 'post': 'create'})
auction_detail = AuctionViewSet.as_view({
    'get': 'retrieve', 'patch': 'partial_update', 'delete': 'destroy'})


class AuctionItemViewSet(ModelWithRequestViewSet):
    queryset = AuctionItem.objects.all()
    serializer_class = AuctionItemSerializer


auction_item_list = AuctionItemViewSet.as_view({
    'get': 'list', 'post': 'create'})


class ConcertViewSet(ModelWithRequestViewSet):
    queryset = Concert.objects.all()
    serializer_class = ConcertSerializer

    def perform_create(self, serializer):
        serializer.save(artist=self.request.user, type='C')


concert_list = ConcertViewSet.as_view({'get': 'list', 'post': 'create'})
concert_detail = ConcertViewSet.as_view({
    'get': 'retrieve', 'patch': 'partial_update', 'delete': 'destroy'})


class CookoffViewSet(ModelWithRequestViewSet):
    queryset = Cookoff.objects.all()
    serializer_class = CookoffSerializer


cookoff_list = CookoffViewSet.as_view({'get': 'list', 'post': 'create'})
cookoff_detail = CookoffViewSet.as_view({
    'get': 'retrieve', 'patch': 'partial_update', 'delete': 'destroy'})
