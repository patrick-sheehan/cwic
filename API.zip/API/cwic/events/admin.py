from django.contrib import admin
from .models import (
    Auction,
    AuctionItem,
    Concert,
    Event,
    Position,
    Starred,
)


class PositionModelAdmin(admin.ModelAdmin):
    list_display = ('lat', 'lon',)
    list_display_links = ('lat', 'lon',)

    class Meta:
        model = Position


admin.site.register(Auction)
admin.site.register(AuctionItem)
admin.site.register(Concert)
admin.site.register(Event)
admin.site.register(Position, PositionModelAdmin)
admin.site.register(Starred)
