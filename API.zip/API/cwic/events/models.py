""" cwic/events/models.py: Models for Events. """

from django.db import models
from django.db.models import Q
from cwic import helpers
from users.models import User

# TODO: alphabetize models

# TODO: remove models that are handled by themselves
EVENT_TYPES = [
    ('A', 'Arts & Crafts'),
    ('B', 'Booth'),
    ('G', 'Putt Putt Golf'),
    ('I', 'Parking'),
    ('L', 'Lake'),
    ('O', 'Other'),
    ('P', 'Park'),
    ('R', 'Raffle'),
    ('S', 'Swimming Pool'),
    ('W', 'Waterslide'),

    # Handled as their own models:
    ('C', 'Concert'),
    ('E', 'Users'),
    ('K', 'Cookoff'),
    ('N', 'Sponsor'),
    ('U', 'Auction'),
]


class Position(models.Model):
    lat = models.FloatField()
    lon = models.FloatField()

    def map_url(self):
        return 'https://www.google.com/maps/@%f,%f' % (self.lat, self.lon)

    def __str__(self):
        return 'lat=%f, lon=%f' % (self.lat, self.lon)


class EventManager(models.Manager):
    """ Custom filtering for Event objects. """

    def for_category_name(self, category_name):
        return [e for e in Event.objects.all()
                if e.type.lower() == category_name.lower()]

    def starred(self, user):
        return [s.event for s in Starred.objects.filter(user=user)]


class Event(models.Model):
    title = models.CharField(max_length=140)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to=helpers.event_location,
                              null=True, blank=True)
    type = models.CharField(max_length=1, choices=EVENT_TYPES, default='O')
    date = models.DateTimeField(null=True, blank=True)

    position = models.ForeignKey(Position, null=True, blank=True)

    objects = EventManager()

    @property
    def popularity(self):
        return 50
        # likes_coef = 0.1
        # likes_i = self.likes.count()
        # likes_total = Like.objects.count()
        # likes_val = likes_i / likes_total if likes_total > 0 else 0
        # likes_score = likes_val * likes_coef
        #
        # comments_coef = 0.2
        # comments_i = self.comments.count()
        # comments_total = Comment.objects.count()
        # comments_val = comments_i / comments_total if comments_total > 0 else 0
        # comments_score = comments_val * comments_coef
        #
        # participants_coef = 0.3
        # participants_i = self.participants.count()
        # participants_total = Participant.objects.count()
        # participants_val = participants_i / participants_total if participants_total > 0 else 0
        # participants_score = participants_val * participants_coef
        #
        # completions_coef = 0.4
        # completions_i = self.completions.count()
        # completions_total = Completion.objects.count()
        # completions_val = completions_i / completions_total if completions_total > 0 else 0
        # completions_score = completions_val * completions_coef
        #
        # return 100 * (likes_score + comments_score +
        #               participants_score + completions_score)

    @property
    def type_verbose(self):
        return dict(EVENT_TYPES)[self.type]

    @property
    def comments(self):
        return Comment.objects.filter(event=self)

    def __str__(self):
        return '%s (%s)' % (self.title, self.type_verbose)

    class Meta:
        ordering = ('-date', 'title',)


class Comment(models.Model):
    """ User feedback on an Event. """

    creator = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    text = models.CharField(max_length=140)
    created = helpers.CreatedTimeField()

    def __str__(self):
        return '%s: \'%s\'' % (self.creator, self.text)


# TODO: rename to StarredEvent
class Starred(models.Model):
    event = models.ForeignKey(Event)
    user = models.ForeignKey(User)

    def __str__(self):
        return '%s starred \'%s\'' % (self.user.username, self.event.title)


class AuctionItem(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to=helpers.auction_item_location,
                              null=True, blank=True)

    def __str__(self):
        return self.name


class Auction(Event):
    items = models.ManyToManyField(AuctionItem, blank=True)

    def __str__(self):
        return 'Auction: %s' % self.title


class Concert(Event):
    artist = models.ForeignKey(User, related_name='concert_artist')

    def __str__(self):
        return 'Concert by %s' % self.artist


class CookoffTeam(models.Model):
    name = models.CharField(max_length=50)
    creator = models.ForeignKey(User, related_name='team_leader')
    members = models.ManyToManyField(User, related_name='team_members')

    def __str__(self):
        return 'Cookoff team: \'%s\'' % self.name


class Cookoff(Event):
    creator = models.ForeignKey(User, related_name='cookoff_creator')
    teams = models.ManyToManyField(CookoffTeam)

    def __str__(self):
        return 'Cookoff: %s' % self.title
